# Micael - The Ultimate Web Development Portfolio 
![Micael](https://i.ibb.co/fHPM38q/image.png)

## Introduction
This is a code repository for the corresponding video tutorial.

Do you know the best way to show your skills to employers or potential clients? Stand out from the crowd by presenting a well-digitalized flexible portfolio and get your dream job.

## Stay up to date with new projects
New major projects coming soon, subscribe to the mailing list to stay up to date https://resource.jsmasterypro.com/newsletter
